
#!/bin/bash

PID=""

cleanup() {
    echo ""
    echo "Stopping ShulkerV2..."
    
    if [ -n "$PID" ]; then
        kill "$PID" 2>/dev/null
        wait "$PID" 2>/dev/null
    fi

    echo "ShulkerV2 stopped. Exiting..."
    exit 0
}

trap cleanup SIGINT SIGTERM

while true
do
    echo "Starting ShulkerV2..."

    ./ShulkerV2 &
    PID=$!

    sleep 500 &
    wait $! 2>/dev/null

    echo "Stopping ShulkerV2..."
    kill "$PID" 2>/dev/null
    wait "$PID" 2>/dev/null
    PID=""

    echo "Restarting in loop..."
done
